There are 3 different program name as bruteforce.py, divideandconquer.py and enhanceddnc.py

each program can executed with command "python bruteforce.py example_input", "python divideandconquer.py example_input", "python enhanceddnc.py example_input"

each program will generate a output file named "output_bruteforce", "output_dnc", "output_enhanceddnc"

note that I used python 2.7.11
